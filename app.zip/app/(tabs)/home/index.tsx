import React from "react";
import { View, Text, TextInput, Image, FlatList, Pressable, ScrollView, StyleSheet } from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";

const categories = ["Cappuccino", "Macchiato", "Latte", "Americano"];
const products = [
  { id: 1, name: "Cappuccino", price: "4.53", rating: 4.8, image: "https://imgs.search.brave.com/I9R9C4q6aniuvFx7nvzClxUsw5QmaGe6tOT6HcMiN6s/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pbWcu/ZnJlZXBpay5jb20v/ZnJlZS1waG90by9s/YXR0ZS1jb2ZmZWVf/MTEyMi0yNzI4Lmpw/Zz9zZW10PWFpc19o/eWJyaWQ" },
  { id: 2, name: "Cappuccino", price: "4.53", rating: 4.8, image: "https://imgs.search.brave.com/I9R9C4q6aniuvFx7nvzClxUsw5QmaGe6tOT6HcMiN6s/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pbWcu/ZnJlZXBpay5jb20v/ZnJlZS1waG90by9s/YXR0ZS1jb2ZmZWVf/MTEyMi0yNzI4Lmpw/Zz9zZW10PWFpc19o/eWJyaWQ" },
];

export default function Home() {
    const insets = useSafeAreaInsets();
  
    return (
        <View>
            <LinearGradient colors={["rgba(19,19,19,1)", "rgba(49,49,49,1)"]} style={{ height: "30%" ,alignSelf:"flex-start"}}>
                <View style={styles.header}>
                    <View>
                        <Text style={styles.locationLabel}>Location</Text>
                        <Text style={styles.location}>Bilzen, Tanjungbalai</Text>
                    </View>
                    <Image source={{ uri: "https://randomuser.me/api/portraits/women/1.jpg" }} style={styles.profileImage} />
                </View>
                <View style={styles.searchContainer}>
                    <Ionicons name="search" size={20} color="#666" style={styles.searchIcon} />
                    <TextInput placeholder="Search coffee" style={styles.searchInput} />
                    <Pressable style={styles.filterButton}>
                        <MaterialIcons name="tune" size={24} color="white" />
                    </Pressable>
                </View>
            </LinearGradient>

            {/* Promo Banner */}
            <View style={styles.promoBanner}>
                <LinearGradient colors={["rgba(0,0,0,0.6)", "rgba(0,0,0,1)"]} style={styles.promoOverlay} />
                <Text style={styles.promoTag}>Promo</Text>
                <Text style={styles.promoText}>Buy one get one Free</Text>
            </View>

            {/* Categories */}
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categories}>
                {categories.map((cat, index) => (
                    <Pressable key={index} style={[styles.categoryButton, index === 0 && styles.activeCategory]}>
                        <Text style={[styles.categoryText, index === 0 && styles.activeCategoryText]}>{cat}</Text>
                    </Pressable>
                ))}
            </ScrollView>

            {/* Product List */}
            <FlatList
                data={products}
                keyExtractor={(item) => item.id.toString()}
                numColumns={2}
                columnWrapperStyle={{ justifyContent: "space-between" }}
                contentContainerStyle={styles.productList}
                renderItem={({ item }) => (
                    <View style={styles.productCard}>
                        <Image source={{ uri: item.image }} style={styles.productImage} />
                        <Text style={styles.productRating}>⭐ {item.rating}</Text>
                        <Text style={styles.productName}>{item.name}</Text>
                        <Text style={styles.productPrice}>$ {item.price}</Text>
                        <Pressable style={styles.addButton}>
                            <Ionicons name="add" size={20} color="white" />
                        </Pressable>
                    </View>
                )}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: "#F7F7F7" },
    header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 20 },
    locationLabel: { fontSize: 12, color: "gray" },
    location: { fontSize: 16, fontWeight: "bold" },
    profileImage: { width: 40, height: 40, borderRadius: 20 },
    searchContainer: { flexDirection: "row", backgroundColor: "#FFF", marginHorizontal: 20, borderRadius: 10, padding: 10, alignItems: "center" },
    searchIcon: { marginRight: 10 },
    searchInput: { flex: 1 },
    filterButton: { backgroundColor: "#D17842", padding: 10, borderRadius: 10 },
    promoBanner: { margin: 20, height: 120, backgroundColor: "#333", borderRadius: 10, padding: 15, justifyContent: "flex-end" },
    promoOverlay: { ...StyleSheet.absoluteFillObject, borderRadius: 10 },
    promoTag: { color: "white", backgroundColor: "#D17842", paddingHorizontal: 10, paddingVertical: 2, borderRadius: 5, alignSelf: "flex-start", marginBottom: 5 },
    promoText: { color: "white", fontSize: 18, fontWeight: "bold" },
    categories: { flexDirection: "row", marginHorizontal: 20 },
    categoryButton: { padding: 10, backgroundColor: "#EEE", borderRadius: 20, marginRight: 10 },
    activeCategory: { backgroundColor: "#D17842" },
    categoryText: { fontSize: 14 },
    activeCategoryText: { color: "white" },
    productList: { paddingHorizontal: 20, paddingBottom: 100 },
    productCard: { backgroundColor: "#FFF", borderRadius: 10, padding: 10, marginBottom: 15, width: "48%" },
    productImage: { width: "100%", height: 100, borderRadius: 10 },
    productRating: { fontSize: 12, color: "#666", marginTop: 5 },
    productName: { fontSize: 16, fontWeight: "bold", marginTop: 5 },
    productPrice: { fontSize: 14, color: "#D17842", marginTop: 5 },
    addButton: { position: "absolute", bottom: 10, right: 10, backgroundColor: "#D17842", padding: 6, borderRadius: 10 },
});