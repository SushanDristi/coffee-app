
import React from 'react';
import { View, Text } from 'react-native';

const fav = () => {
  return (
    <View>
      <Text>Fav</Text>
    </View>
  );
}

export default fav;
