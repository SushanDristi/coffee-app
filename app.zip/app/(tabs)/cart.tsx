import React from 'react';
import { View, Text } from 'react-native';

const cart = () => {
  return (
    <View>
      <Text>Cart</Text>
    </View>
  );
}

export default cart;
