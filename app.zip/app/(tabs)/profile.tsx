

import React from 'react';
import { View, Text } from 'react-native';

const profile = () => {
  return (
    <View>
      <Text>Profile</Text>
    </View>
  );
}

export default profile;
